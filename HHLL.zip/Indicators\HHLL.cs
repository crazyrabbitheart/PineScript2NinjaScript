#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
//using System.Speech.AudioFormat; 
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HHLL : Indicator
	{
		private int 	barsback;
		private double 	prevhigh;
		private double 	prevlow;
		private double 	curhigh;
		private double 	curlow;
		private double 	offset;
		private double 	curATR;
		private double 	toffset;
		private ATR 	myATR;
		private Swing 	mySwing;
		private double 	tOffset;		
		private int		myBarUp, myBarDown;
		private bool 	posDir;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Labels the swing points";
				Name										= "HHLL";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				Strength					= 5;
				TextOffset					= 3;
				LookBack					= 50;
				DTBStrength					= 15;
				TextFont					= new NinjaTrader.Gui.Tools.SimpleFont("Arial", 12); 
				DBcolor						= Brushes.Gold;
				DTcolor						= Brushes.Gold;
				HHcolor						= Brushes.Green;
				HLcolor						= Brushes.Green;
				LLcolor						= Brushes.Red;
				LHcolor						= Brushes.Red;
				EnabledShowLabel			= true;
				AUcol 						= Brushes.Green;
				ADcol 						= Brushes.Red;
				BUcol 						= Brushes.Blue;
				BDcol 						= Brushes.Red;
				posDir						= true;
				
								
				AddPlot(new Stroke(Brushes.Green,	2), PlotStyle.Dot, "plot high");
				AddPlot(new Stroke(Brushes.Red,	2), PlotStyle.Dot, "plot low");
			}
			else if (State == State.DataLoaded)
			{
				myATR = ATR(14);			
				mySwing = Swing(Strength);
				tOffset = TextOffset * TickSize;
			}			
		}

		protected override void OnBarUpdate()
		{
					
			if (CurrentBar < LookBack + 1) return;
			
			Values[0][0] = Values[0][1];
			Values[1][0] = Values[1][1];
			
			if(Close[0] > Values[0][0]){
				BarBrushes[0] = BUcol;
			} else if(Close[0] < Values[1][0]){
				BarBrushes[0] = BDcol;
			} else {
				BarBrushes[0] = BarBrushes[1];
			}
			
			barsback = mySwing.SwingHighBar(0,2,LookBack);
		
			if (barsback == -1) 
				return; 
			Print(CurrentBar);
			
			prevhigh = mySwing.SwingHigh[barsback]; 
						
			barsback = mySwing.SwingHighBar(0,1,LookBack);
			
			if (barsback == -1) 
				return; 
			
			curhigh = mySwing.SwingHigh[barsback]; 
			
			curATR	= myATR[barsback];	
			offset	= curATR * DTBStrength / 100;			
					
//			if (curhigh < prevhigh + offset && curhigh > prevhigh - offset && CurrentBar - barsback != myBarUp)
//			{
//				myBarUp = CurrentBar - barsback;
//				if (EnabledShowLabel)
//					Draw.Text(this, "DT"+CurrentBar, true, "DT", barsback, High[barsback] + tOffset, 0, DTcolor, 
//						TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);					
//			}
//			else 
			if (curhigh > prevhigh && CurrentBar - barsback != myBarUp)
			{
				myBarUp = CurrentBar - barsback;
				if (EnabledShowLabel)
					Draw.Text(this, "HH"+CurrentBar, true, "HH", barsback, High[barsback] + tOffset, 0, HHcolor,
						TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);				
				for (int i=0;i<=Strength;i++){
					Values[0][i] = High[Strength];					
				}
			}
			else if (CurrentBar - barsback != myBarUp)
			{
				myBarUp = CurrentBar - barsback;
				if (EnabledShowLabel)
					Draw.Text(this, "LH"+CurrentBar, true, "LH",barsback, High[barsback] + tOffset, 0,  LHcolor, 
						TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);				
				for (int i=0;i<=Strength;i++){
					Values[0][i] = High[Strength];
				}
			}else{
				for (int i=0;i<=Strength;i++){
					Values[0][i] = Values[0][Strength+1];
				}	
			}
			
			barsback = mySwing.SwingLowBar(0,2,LookBack);
			
			if (barsback == -1) 
				return; 
			
			prevlow = mySwing.SwingLow[barsback]; 
						
			barsback = mySwing.SwingLowBar(0,1,LookBack);
			
			if (barsback == -1) 
				return; 
			
			curlow = mySwing.SwingLow[barsback];
			
			curATR	= myATR[barsback];	
			offset	= curATR * DTBStrength / 100;
			
//			if (curlow > prevlow - offset && curlow < prevlow + offset && CurrentBar - barsback != myBarDown)
//			{
//				myBarDown = CurrentBar - barsback;
//				Draw.Text(this, "DB"+CurrentBar, true, "DB", barsback, Low[barsback] - tOffset, 0, DBcolor,
//					TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
//			}
//			else 
			if (curlow < prevlow && CurrentBar - barsback != myBarDown)
			{
				myBarDown = CurrentBar - barsback;
				if (EnabledShowLabel)
					Draw.Text(this, "LL"+CurrentBar, true, "LL", barsback, Low[barsback] - tOffset, 0,  LLcolor,
						TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
				for (int i=0;i<=Strength;i++){
					Values[1][i] = Low[Strength];
				}
			}
			else if (CurrentBar - barsback != myBarDown)
			{
				myBarDown = CurrentBar - barsback;
				if (EnabledShowLabel)
					Draw.Text(this, "HL"+CurrentBar, true, "HL", barsback, Low[barsback] - tOffset, 0, HLcolor,
						TextFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);				
				for (int i=0;i<=Strength;i++){
					Values[1][i] = Low[Strength];
				}
			}else{
				for (int i=0;i<=Strength;i++){
					Values[1][i] = Values[1][Strength+1];
				}				
			}
			
			if(Close[0] > Values[0][0] && Open[0] < Values[0][0]){
				Draw.ArrowUp(this, "MyArrowUp"+CurrentBar, true, 0, Low[0] - TickSize, AUcol);					
			} else if(Close[0] < Values[1][0] && Open[0] > Values[1][0]){
				Draw.ArrowDown(this, "MyArrowDown"+CurrentBar, true, 0, High[0] + TickSize, ADcol);
			}
			
//			if (BarBrushes[0] == BDcol && BarBrushes[1] == BUcol) {
//				Draw.ArrowDown(this, "MyArrowDown"+CurrentBar, true, 0, High[0] + TickSize, ADcol);
//			}
			
//			if (BarBrushes[0] == BUcol && BarBrushes[1] == BDcol) {
//				Draw.ArrowUp(this, "MyArrowUp"+CurrentBar, true, 0, Low[0] - TickSize, AUcol);					
//			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Strength", Description="Swing strength, number of bars", Order=1, GroupName="Parameters")]
		public int Strength
		{ get; set; }

		[Display(Name="EnabledShowLabel", Order=2, GroupName="Parameters")]
		public bool EnabledShowLabel
		{ get; set; }
		
		[XmlIgnore]
		[Display(Name="ArrowUp Color", Description="ArrowUp Color", Order=3, GroupName="Parameters")]
		public Brush AUcol
		{ get; set; }	

		[Browsable(false)]
		public string AUcolSerializable
		{
			get { return Serialize.BrushToString(AUcol); }
			set { LHcolor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="ArrowDown Color", Description="ArrowDown Color", Order=4, GroupName="Parameters")]
		public Brush ADcol
		{ get; set; }	

		[Browsable(false)]
		public string ADcolSerializable
		{
			get { return Serialize.BrushToString(ADcol); }
			set { DBcolor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name="BarUp Color", Description="BarUp Color", Order=4, GroupName="Parameters")]
		public Brush BUcol
		{ get; set; }	

		[Browsable(false)]
		public string BUcolSerializable
		{
			get { return Serialize.BrushToString(BUcol); }
			set { LHcolor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="BarDown Color", Description="BarDown Color", Order=4, GroupName="Parameters")]
		public Brush BDcol
		{ get; set; }	

		[Browsable(false)]
		public string BDcolSerializable
		{
			get { return Serialize.BrushToString(BDcol); }
			set { DBcolor = Serialize.StringToBrush(value); }
		}
		
		[Range(0, int.MaxValue)]
		[Display(Name="TextOffset", Description="Number of ticks to offset text from high/low", Order=5, GroupName="Parameters")]
		public int TextOffset
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="LookBack", Description="Number of bars ago to check", Order=6, GroupName="Parameters")]
		public int LookBack
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DTBStrength", Order=7, GroupName="Parameters")]
		public int DTBStrength
		{ get; set; }	

		[Display(Name	= "Font, size, type, style",
		Description		= "select font, style, size to display on chart",
		GroupName		= "Text",
		Order			= 1)]
		public Gui.Tools.SimpleFont TextFont
		{ get; set; }	
		
		[XmlIgnore]
		[Display(Name="HH Color", Description="(text) Higher High color", Order=8, GroupName="Text")]
		public Brush HHcolor
		{ get; set; }	

		[Browsable(false)]
		public string HHcolorSerializable
		{
			get { return Serialize.BrushToString(HHcolor); }
			set { HHcolor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="HL Color", Description="(text) Higher Low color", Order=9, GroupName="Text")]
		public Brush HLcolor
		{ get; set; }	

		[Browsable(false)]
		public string HLcolorSerializable
		{
			get { return Serialize.BrushToString(HLcolor); }
			set { HLcolor = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(Name="DT Color", Description="(text) Double Top color", Order=10, GroupName="Text")]
		public Brush DTcolor
		{ get; set; }	

		[Browsable(false)]
		public string DTcolorSerializable
		{
			get { return Serialize.BrushToString(DTcolor); }
			set { DTcolor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="LL Color", Description="(text) Lower Low color", Order=11, GroupName="Text")]
		public Brush LLcolor
		{ get; set; }	

		[Browsable(false)]
		public string LLcolorSerializable
		{
			get { return Serialize.BrushToString(LLcolor); }
			set { LLcolor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name="LH Color", Description="(text) Lower High color", Order=12, GroupName="Text")]
		public Brush LHcolor
		{ get; set; }	

		[Browsable(false)]
		public string LHcolorSerializable
		{
			get { return Serialize.BrushToString(LHcolor); }
			set { LHcolor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="DB Color", Description="(text) Double Bottom color", Order=13, GroupName="Text")]
		public Brush DBcolor
		{ get; set; }	

		[Browsable(false)]
		public string DBcolorSerializable
		{
			get { return Serialize.BrushToString(DBcolor); }
			set { DBcolor = Serialize.StringToBrush(value); }
		}		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HHLL[] cacheHHLL;
		public HHLL HHLL(int strength, int lookBack, int dTBStrength)
		{
			return HHLL(Input, strength, lookBack, dTBStrength);
		}

		public HHLL HHLL(ISeries<double> input, int strength, int lookBack, int dTBStrength)
		{
			if (cacheHHLL != null)
				for (int idx = 0; idx < cacheHHLL.Length; idx++)
					if (cacheHHLL[idx] != null && cacheHHLL[idx].Strength == strength && cacheHHLL[idx].LookBack == lookBack && cacheHHLL[idx].DTBStrength == dTBStrength && cacheHHLL[idx].EqualsInput(input))
						return cacheHHLL[idx];
			return CacheIndicator<HHLL>(new HHLL(){ Strength = strength, LookBack = lookBack, DTBStrength = dTBStrength }, input, ref cacheHHLL);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HHLL HHLL(int strength, int lookBack, int dTBStrength)
		{
			return indicator.HHLL(Input, strength, lookBack, dTBStrength);
		}

		public Indicators.HHLL HHLL(ISeries<double> input , int strength, int lookBack, int dTBStrength)
		{
			return indicator.HHLL(input, strength, lookBack, dTBStrength);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HHLL HHLL(int strength, int lookBack, int dTBStrength)
		{
			return indicator.HHLL(Input, strength, lookBack, dTBStrength);
		}

		public Indicators.HHLL HHLL(ISeries<double> input , int strength, int lookBack, int dTBStrength)
		{
			return indicator.HHLL(input, strength, lookBack, dTBStrength);
		}
	}
}

#endregion
